	


	<!-- Footer section -->
	<footer class="footer-section">
		<h2>Follow us at:</h2>
		<a href=""><img src="assets/images/fb.png"></a>
		<a href=""><img src="assets/images/instagram.png"></a>
		<a href=""><img src="assets/images/twitter.png"></a>
	</footer>
	<!-- Footer section end -->




	<!--====== Javascripts & Jquery ======-->
	<script src="assets/js/jquery-2.1.4.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/magnific-popup.min.js"></script>
	<script src="assets/js/owl.carousel.min.js"></script>
	<script src="assets/js/circle-progress.min.js"></script>
	<script src="assets/js/main.js"></script>
</body>
</html>